import { Button } from "./ui/button";
import { Menu, X } from "lucide-react";
import { useState } from "react";

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-md border-b border-gray-800">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-gradient-to-r from-yellow-400 to-purple-600 rounded-lg flex items-center justify-center">
              <span className="text-black font-bold">R+</span>
            </div>
            <span className="text-white font-bold text-xl">RapideIPTVPlus</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#home" className="text-gray-300 hover:text-yellow-400 transition-colors">Home</a>
            <a href="#pricing" className="text-gray-300 hover:text-yellow-400 transition-colors">Pricing</a>
            <a href="#features" className="text-gray-300 hover:text-yellow-400 transition-colors">Features</a>
            <a href="#how-to-watch" className="text-gray-300 hover:text-yellow-400 transition-colors">How to Watch</a>
            <a href="#contact" className="text-gray-300 hover:text-yellow-400 transition-colors">Contact</a>
          </nav>

          {/* CTA Button */}
          <div className="hidden md:flex">
            <Button className="bg-gradient-to-r from-yellow-400 to-purple-600 text-black hover:from-yellow-500 hover:to-purple-700">
              Get Started
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-white"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-gray-800">
            <nav className="flex flex-col space-y-4 mt-4">
              <a href="#home" className="text-gray-300 hover:text-yellow-400 transition-colors">Home</a>
              <a href="#pricing" className="text-gray-300 hover:text-yellow-400 transition-colors">Pricing</a>
              <a href="#features" className="text-gray-300 hover:text-yellow-400 transition-colors">Features</a>
              <a href="#how-to-watch" className="text-gray-300 hover:text-yellow-400 transition-colors">How to Watch</a>
              <a href="#contact" className="text-gray-300 hover:text-yellow-400 transition-colors">Contact</a>
              <Button className="bg-gradient-to-r from-yellow-400 to-purple-600 text-black hover:from-yellow-500 hover:to-purple-700 mt-4">
                Get Started
              </Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}