import { Card, CardContent } from "./ui/card";
import { Tv, Smartphone, Monitor, Wifi } from "lucide-react";

const devices = [
  {
    icon: Tv,
    title: "Smart TV",
    description: "Samsung, LG, Sony, Android TV, and all major smart TV brands",
    apps: ["Smart IPTV", "SS IPTV", "IBO Player"]
  },
  {
    icon: Smartphone,
    title: "Mobile Devices",
    description: "Android phones/tablets and iOS iPhone/iPad devices",
    apps: ["IBO Player", "IPTV Smarters", "TiviMate"]
  },
  {
    icon: Monitor,
    title: "Streaming Devices",
    description: "Amazon Firestick, Roku, Apple TV, Chromecast, and more",
    apps: ["IBO Player", "IPTV Smarters", "Perfect Player"]
  },
  {
    icon: Wifi,
    title: "PC & Mac",
    description: "Windows, macOS, and Linux desktop computers",
    apps: ["VLC Player", "IBO Player", "IPTV Smarters"]
  }
];

export function HowToWatch() {
  return (
    <section id="how-to-watch" className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
            How to <span className="bg-gradient-to-r from-yellow-400 to-purple-600 bg-clip-text text-transparent">Watch</span>
          </h2>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto">
            Stream on any device, anywhere. Our IPTV service works seamlessly across all major platforms.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {devices.map((device, index) => (
            <Card key={index} className="bg-gray-800 border-gray-700 hover:border-yellow-400/50 transition-all duration-300 group">
              <CardContent className="p-6 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-yellow-400/20 to-purple-600/20 rounded-xl mb-4 group-hover:from-yellow-400/30 group-hover:to-purple-600/30 transition-all duration-300">
                  <device.icon className="w-8 h-8 text-yellow-400" />
                </div>
                <h3 className="text-white font-semibold mb-2">{device.title}</h3>
                <p className="text-gray-400 text-sm mb-4">{device.description}</p>
                <div className="space-y-1">
                  {device.apps.map((app, appIndex) => (
                    <div key={appIndex} className="text-xs text-yellow-400 bg-yellow-400/10 px-2 py-1 rounded-full inline-block mr-1">
                      {app}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Setup Steps */}
        <div className="bg-gray-800 rounded-2xl p-8">
          <h3 className="text-2xl font-bold text-white text-center mb-8">Simple 3-Step Setup</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-purple-600 rounded-full flex items-center justify-center text-black font-bold text-xl mb-4 mx-auto">
                1
              </div>
              <h4 className="text-white font-semibold mb-2">Choose Your Plan</h4>
              <p className="text-gray-400 text-sm">Select the subscription plan that best fits your needs and budget.</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-purple-600 rounded-full flex items-center justify-center text-black font-bold text-xl mb-4 mx-auto">
                2
              </div>
              <h4 className="text-white font-semibold mb-2">Receive Login Details</h4>
              <p className="text-gray-400 text-sm">Get your M3U URL and login credentials instantly after payment.</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-purple-600 rounded-full flex items-center justify-center text-black font-bold text-xl mb-4 mx-auto">
                3
              </div>
              <h4 className="text-white font-semibold mb-2">Start Watching</h4>
              <p className="text-gray-400 text-sm">Install the app on your device and start streaming immediately.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}