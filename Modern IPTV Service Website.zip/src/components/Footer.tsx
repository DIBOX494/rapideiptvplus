import { MessageCircle, Mail, Shield, Star } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-gray-900 border-t border-gray-800">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-r from-yellow-400 to-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-black font-bold">R+</span>
              </div>
              <span className="text-white font-bold text-xl">RapideIPTVPlus</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed mb-4">
              Premium IPTV service with over 22,000 live channels and 120,000+ movies & series. 
              Stream in 4K quality on any device.
            </p>
            <div className="flex items-center space-x-2">
              <div className="flex space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <span className="text-gray-400 text-sm">4.9/5 Rating</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#home" className="text-gray-400 hover:text-yellow-400 transition-colors text-sm">Home</a></li>
              <li><a href="#pricing" className="text-gray-400 hover:text-yellow-400 transition-colors text-sm">Pricing Plans</a></li>
              <li><a href="#features" className="text-gray-400 hover:text-yellow-400 transition-colors text-sm">Features</a></li>
              <li><a href="#how-to-watch" className="text-gray-400 hover:text-yellow-400 transition-colors text-sm">How to Watch</a></li>
              <li><a href="#faq" className="text-gray-400 hover:text-yellow-400 transition-colors text-sm">FAQ</a></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-white font-semibold mb-4">Support</h3>
            <ul className="space-y-3">
              <li>
                <a 
                  href="https://wa.me/447588680050" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center text-gray-400 hover:text-green-400 transition-colors text-sm"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  WhatsApp Support
                </a>
              </li>
              <li>
                <a 
                  href="mailto:support@rapideiptvplus.com"
                  className="flex items-center text-gray-400 hover:text-blue-400 transition-colors text-sm"
                >
                  <Mail className="w-4 h-4 mr-2" />
                  Email Support
                </a>
              </li>
              <li className="flex items-center text-gray-400 text-sm">
                <Shield className="w-4 h-4 mr-2" />
                24/7 Live Chat
              </li>
            </ul>
          </div>

          {/* Legal & Security */}
          <div>
            <h3 className="text-white font-semibold mb-4">Security & Trust</h3>
            <ul className="space-y-2">
              <li><span className="text-gray-400 text-sm">✓ Secure SSL Encryption</span></li>
              <li><span className="text-gray-400 text-sm">✓ 24hr Money Back Guarantee</span></li>
              <li><span className="text-gray-400 text-sm">✓ 99.9% Uptime Guarantee</span></li>
              <li><span className="text-gray-400 text-sm">✓ Instant Activation</span></li>
            </ul>

            {/* Payment Methods */}
            <div className="mt-4">
              <p className="text-gray-400 text-sm mb-2">Payment Methods:</p>
              <div className="flex space-x-2">
                <div className="bg-blue-600 text-white px-2 py-1 rounded text-xs">PayPal</div>
                <div className="bg-blue-800 text-white px-2 py-1 rounded text-xs">VISA</div>
                <div className="bg-red-600 text-white px-2 py-1 rounded text-xs">MC</div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-500 text-sm">
              © 2024 RapideIPTVPlus. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-500 hover:text-gray-400 text-sm">Privacy Policy</a>
              <a href="#" className="text-gray-500 hover:text-gray-400 text-sm">Terms of Service</a>
              <a href="#" className="text-gray-500 hover:text-gray-400 text-sm">Refund Policy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}