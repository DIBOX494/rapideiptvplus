import { Gift, Sparkles } from "lucide-react";

export function PromoBanner() {
  return (
    <div className="bg-gradient-to-r from-purple-600 to-yellow-400 py-4">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-center text-black">
          <div className="flex items-center space-x-3">
            <div className="flex items-center">
              <Gift className="w-5 h-5 mr-2" />
              <Sparkles className="w-4 h-4 mr-2" />
            </div>
            <span className="font-bold text-sm md:text-base">
              🎉 FREE IBO Player Pro included with 12+ month plans!
            </span>
            <div className="flex items-center">
              <Sparkles className="w-4 h-4 ml-2" />
              <Gift className="w-5 h-5 ml-2" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}