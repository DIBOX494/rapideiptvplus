import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Check, Star, Flame } from "lucide-react";
import { useEffect } from "react";

const plans = [
  {
    duration: "1 Month",
    price: "$16.99",
    popular: false,
    bestValue: false,
    sellAppProductId: "325037",
    features: [
      "+22,000 Live TV Channels",
      "+120,000 Movies & Series (VOD)",
      "4K, UHD, FHD, HD Channels",
      "Instant Activation!",
      "Anti-Buffer™ 9.8",
      "Works on any device",
      "Always Uptime Server",
      "Pay Per View (PPV)",
      "24/7 Live Chat Support"
    ]
  },
  {
    duration: "3 Months",
    price: "$33.99",
    popular: false,
    bestValue: false,
    sellAppProductId: "325160",
    features: [
      "+22,000 Live TV Channels",
      "+120,000 Movies & Series (VOD)",
      "4K, UHD, FHD, HD Channels",
      "Instant Activation!",
      "Anti-Buffer™ 9.8",
      "Works on any device",
      "Always Uptime Server",
      "Pay Per View (PPV)",
      "24/7 Live Chat Support"
    ]
  },
  {
    duration: "6 Months",
    price: "$46.99",
    popular: false,
    bestValue: false,
    sellAppProductId: "325161",
    features: [
      "+22,000 Live TV Channels",
      "+120,000 Movies & Series (VOD)",
      "4K, UHD, FHD, HD Channels",
      "Instant Activation!",
      "Anti-Buffer™ 9.8",
      "Works on any device",
      "Always Uptime Server",
      "Pay Per View (PPV)",
      "24/7 Live Chat Support"
    ]
  },
  {
    duration: "12 Months",
    price: "$70.00",
    popular: true,
    bestValue: false,
    sellAppProductId: "325162",
    features: [
      "+22,000 Live TV Channels",
      "+120,000 Movies & Series (VOD)",
      "4K, UHD, FHD, HD Channels",
      "Instant Activation!",
      "Anti-Buffer™ 9.8",
      "Works on any device",
      "Always Uptime Server",
      "Pay Per View (PPV)",
      "24/7 Live Chat Support",
      "✅ Free IBO Player Pro included"
    ]
  },
  {
    duration: "24 Months",
    price: "$124.00",
    popular: false,
    bestValue: true,
    sellAppProductId: "325163",
    features: [
      "+22,000 Live TV Channels",
      "+120,000 Movies & Series (VOD)",
      "4K, UHD, FHD, HD Channels",
      "Instant Activation!",
      "Anti-Buffer™ 9.8",
      "Works on any device",
      "Always Uptime Server",
      "Pay Per View (PPV)",
      "24/7 Live Chat Support",
      "✅ Free IBO Player Pro included"
    ]
  }
];

export function PricingPlans() {
  useEffect(() => {
    // Load SellApp embed script
    const script = document.createElement('script');
    script.src = 'https://cdn.sell.app/embed/script.js';
    script.type = 'module';
    document.head.appendChild(script);

    // Load SellApp CSS
    const link = document.createElement('link');
    link.href = 'https://cdn.sell.app/embed/style.css';
    link.rel = 'stylesheet';
    document.head.appendChild(link);

    return () => {
      // Cleanup
      document.head.removeChild(script);
      document.head.removeChild(link);
    };
  }, []);

  return (
    <section id="pricing" className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
            Choose Your <span className="bg-gradient-to-r from-yellow-400 to-purple-600 bg-clip-text text-transparent">Perfect Plan</span>
          </h2>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto">
            All plans include the same premium features. Choose the duration that works best for you.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 max-w-7xl mx-auto">
          {plans.map((plan, index) => (
            <Card 
              key={index} 
              className={`relative bg-gray-800 border-gray-700 hover:border-yellow-400/50 transition-all duration-300 ${
                plan.popular || plan.bestValue ? 'transform scale-105 border-yellow-400' : ''
              }`}
            >
              {/* Popular/Best Value Badge */}
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-gradient-to-r from-yellow-400 to-purple-600 text-black px-4 py-1">
                    <Star className="w-3 h-3 mr-1" />
                    Most Popular
                  </Badge>
                </div>
              )}
              {plan.bestValue && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-gradient-to-r from-red-500 to-orange-500 text-white px-4 py-1">
                    <Flame className="w-3 h-3 mr-1" />
                    Best Value
                  </Badge>
                </div>
              )}

              <CardHeader className="text-center pb-4">
                <CardTitle className="text-white text-xl mb-2">{plan.duration}</CardTitle>
                <div className="text-3xl font-bold text-yellow-400">{plan.price}</div>
              </CardHeader>

              <CardContent className="space-y-4">
                <ul className="space-y-3">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start text-sm text-gray-300">
                      <Check className="w-4 h-4 text-yellow-400 mr-2 mt-0.5 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* SellApp integration for all plans */}
                <button
                  data-sell-store="67080"
                  data-sell-product={plan.sellAppProductId}
                  data-sell-theme=""
                  data-sell-darkmode="true"
                  className={`w-full mt-6 px-4 py-2 rounded-md transition-colors duration-200 font-medium ${
                    plan.popular || plan.bestValue
                      ? 'bg-gradient-to-r from-yellow-400 to-purple-600 text-black hover:from-yellow-500 hover:to-purple-700'
                      : 'bg-gray-700 text-white hover:bg-gray-600'
                  }`}
                >
                  Buy Now
                </button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Payment Methods */}
        <div className="text-center mt-12">
          <p className="text-gray-400 mb-4">Secure payment methods accepted:</p>
          <div className="flex justify-center items-center space-x-6 opacity-70">
            <div className="bg-blue-600 text-white px-3 py-1 rounded text-sm font-bold">PayPal</div>
            <div className="bg-blue-800 text-white px-3 py-1 rounded text-sm font-bold">VISA</div>
            <div className="bg-red-600 text-white px-3 py-1 rounded text-sm font-bold">Mastercard</div>
            <div className="bg-gray-700 text-white px-3 py-1 rounded text-sm">SSL Secure</div>
          </div>
        </div>
      </div>
    </section>
  );
}