import { Card, CardContent } from "./ui/card";
import { 
  Play, 
  Shield, 
  Zap, 
  Globe, 
  Star, 
  Clock, 
  Tv, 
  Smartphone,
  HeadphonesIcon,
  CheckCircle,
  Wifi,
  Download
} from "lucide-react";

const features = [
  {
    icon: Play,
    title: "22,000+ Live Channels",
    description: "Access premium TV channels from around the world in ultra-high definition quality."
  },
  {
    icon: Star,
    title: "120,000+ Movies & Series",
    description: "Massive VOD library with the latest movies, TV shows, and exclusive content."
  },
  {
    icon: Zap,
    title: "Anti-Buffer™ 9.8",
    description: "Advanced streaming technology ensures smooth playback without interruptions."
  },
  {
    icon: Tv,
    title: "4K/UHD Quality",
    description: "Crystal clear picture quality supporting 4K, UHD, FHD, and HD resolutions."
  },
  {
    icon: Globe,
    title: "Works on Any Device",
    description: "Compatible with Smart TV, Android, iOS, Firestick, PC, and all major platforms."
  },
  {
    icon: Clock,
    title: "Instant Activation",
    description: "Get started immediately after purchase with instant account activation."
  },
  {
    icon: Shield,
    title: "Always Uptime Server",
    description: "99.9% uptime guarantee with reliable servers for uninterrupted streaming."
  },
  {
    icon: CheckCircle,
    title: "Pay Per View (PPV)",
    description: "Access exclusive live events and pay-per-view content at no extra cost."
  },
  {
    icon: HeadphonesIcon,
    title: "24/7 Live Chat Support",
    description: "Round-the-clock customer support to help you with any questions or issues."
  },
  {
    icon: Smartphone,
    title: "Multi-Device Support",
    description: "Stream on multiple devices simultaneously with one subscription."
  },
  {
    icon: Wifi,
    title: "Low Bandwidth Friendly",
    description: "Optimized for various internet speeds without compromising quality."
  },
  {
    icon: Download,
    title: "Regular Updates",
    description: "Continuous content updates with new channels and features added regularly."
  }
];

export function Features() {
  return (
    <section id="features" className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
            Why Choose <span className="bg-gradient-to-r from-yellow-400 to-purple-600 bg-clip-text text-transparent">RapideIPTVPlus</span>
          </h2>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto">
            Experience premium IPTV streaming with cutting-edge technology and unmatched reliability.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="bg-gray-900 border-gray-800 hover:border-yellow-400/50 transition-all duration-300 group">
              <CardContent className="p-6 text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-gradient-to-r from-yellow-400/20 to-purple-600/20 rounded-lg mb-4 group-hover:from-yellow-400/30 group-hover:to-purple-600/30 transition-all duration-300">
                  <feature.icon className="w-6 h-6 text-yellow-400" />
                </div>
                <h3 className="text-white font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}