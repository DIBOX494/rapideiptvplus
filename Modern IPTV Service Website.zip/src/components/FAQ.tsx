import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "./ui/accordion";

const faqs = [
  {
    question: "What payment methods do you accept?",
    answer: "We accept PayPal, Visa, Mastercard, and other major credit cards. All payments are processed securely through encrypted payment gateways."
  },
  {
    question: "How do I install and setup IPTV?",
    answer: "After purchase, you'll receive login credentials and setup instructions. Simply download the recommended app (IBO Player, IPTV Smarters, etc.) on your device, enter your credentials, and start watching. We also provide 24/7 setup support."
  },
  {
    question: "What is your refund policy?",
    answer: "We offer a 24-hour money-back guarantee. If you're not satisfied with the service within the first 24 hours, contact our support team for a full refund."
  },
  {
    question: "How many devices can I use simultaneously?",
    answer: "All our plans support multiple device connections. You can stream on Smart TVs, phones, tablets, computers, and streaming devices using the same account."
  },
  {
    question: "Do you provide customer support?",
    answer: "Yes! We offer 24/7 live chat support to help with any questions, technical issues, or setup assistance. Our support team is always ready to help."
  },
  {
    question: "What internet speed do I need?",
    answer: "For optimal streaming: SD quality requires 3 Mbps, HD quality requires 8 Mbps, and 4K quality requires 25 Mbps. Our service is optimized to work with various internet speeds."
  },
  {
    question: "Is the service legal and safe?",
    answer: "Yes, our IPTV service operates legally and provides legitimate content. We use secure servers and encrypted connections to protect your privacy and data."
  },
  {
    question: "Can I watch on Smart TV without additional devices?",
    answer: "Yes! You can install IPTV apps directly on most Smart TVs including Samsung, LG, Sony, and Android TV models. No additional devices needed."
  },
  {
    question: "Do you offer channel lists?",
    answer: "Yes, we provide detailed channel lists upon request. Our package includes over 22,000 live channels covering sports, news, entertainment, movies, and international content."
  },
  {
    question: "How quickly is my account activated?",
    answer: "Account activation is instant! You'll receive your login credentials and setup instructions immediately after payment confirmation, usually within 5 minutes."
  }
];

export function FAQ() {
  return (
    <section id="faq" className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
            Frequently Asked <span className="bg-gradient-to-r from-yellow-400 to-purple-600 bg-clip-text text-transparent">Questions</span>
          </h2>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto">
            Find answers to common questions about our IPTV service, setup, and features.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="bg-gray-800 border-gray-700 rounded-lg px-6"
              >
                <AccordionTrigger className="text-white hover:text-yellow-400 text-left">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-gray-300 leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        {/* Still have questions CTA */}
        <div className="text-center mt-12">
          <p className="text-gray-400 mb-4">Still have questions?</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="https://wa.me/447588680050" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              💬 WhatsApp Support
            </a>
            <a 
              href="mailto:support@rapideiptvplus.com"
              className="inline-flex items-center justify-center px-6 py-3 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors"
            >
              📧 Email Support
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}