import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { MessageCircle, Mail, Clock, Shield } from "lucide-react";

export function Contact() {
  return (
    <section id="contact" className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
            Get in <span className="bg-gradient-to-r from-yellow-400 to-purple-600 bg-clip-text text-transparent">Touch</span>
          </h2>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto">
            Need help or have questions? Our support team is available 24/7 to assist you.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-4xl mx-auto">
          {/* Contact Methods */}
          <div className="space-y-6">
            <Card className="bg-gray-900 border-gray-800 hover:border-yellow-400/50 transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center mr-4">
                    <MessageCircle className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold">WhatsApp Support</h3>
                    <p className="text-gray-400 text-sm">Instant messaging support</p>
                  </div>
                </div>
                <p className="text-gray-300 mb-4">
                  Get instant help via WhatsApp. Our team responds quickly to resolve any issues or questions.
                </p>
                <a 
                  href="https://wa.me/447588680050" 
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  <Button className="bg-green-600 hover:bg-green-700 text-white w-full">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Chat on WhatsApp
                  </Button>
                </a>
              </CardContent>
            </Card>

            <Card className="bg-gray-900 border-gray-800 hover:border-yellow-400/50 transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mr-4">
                    <Mail className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold">Email Support</h3>
                    <p className="text-gray-400 text-sm">Professional assistance</p>
                  </div>
                </div>
                <p className="text-gray-300 mb-4">
                  Send us detailed questions or issues via email for comprehensive support and solutions.
                </p>
                <a href="mailto:support@rapideiptvplus.com">
                  <Button className="bg-blue-600 hover:bg-blue-700 text-white w-full">
                    <Mail className="w-4 h-4 mr-2" />
                    Send Email
                  </Button>
                </a>
              </CardContent>
            </Card>
          </div>

          {/* Support Features */}
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-white mb-6">Why Choose Our Support?</h3>
            
            <div className="space-y-4">
              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 bg-gradient-to-r from-yellow-400/20 to-purple-600/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Clock className="w-5 h-5 text-yellow-400" />
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">24/7 Availability</h4>
                  <p className="text-gray-400 text-sm">Round-the-clock support whenever you need assistance, any day of the week.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 bg-gradient-to-r from-yellow-400/20 to-purple-600/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <MessageCircle className="w-5 h-5 text-yellow-400" />
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">Quick Response</h4>
                  <p className="text-gray-400 text-sm">Fast response times with most queries answered within minutes via WhatsApp.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 bg-gradient-to-r from-yellow-400/20 to-purple-600/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Shield className="w-5 h-5 text-yellow-400" />
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">Expert Technical Help</h4>
                  <p className="text-gray-400 text-sm">Knowledgeable support team to help with setup, troubleshooting, and optimization.</p>
                </div>
              </div>
            </div>

            {/* Contact Info */}
            <div className="bg-gray-900 rounded-lg p-6 border border-gray-800">
              <h4 className="text-white font-semibold mb-4">Contact Information</h4>
              <div className="space-y-3">
                <div className="flex items-center text-gray-300">
                  <MessageCircle className="w-4 h-4 text-green-500 mr-3" />
                  <span>+44 7588 680050</span>
                </div>
                <div className="flex items-center text-gray-300">
                  <Mail className="w-4 h-4 text-blue-500 mr-3" />
                  <span>support@rapideiptvplus.com</span>
                </div>
                <div className="flex items-center text-gray-300">
                  <Clock className="w-4 h-4 text-yellow-400 mr-3" />
                  <span>Available 24/7</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}