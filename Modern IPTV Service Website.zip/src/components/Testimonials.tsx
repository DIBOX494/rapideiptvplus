import { Card, CardContent } from "./ui/card";
import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    name: "Michael Johnson",
    location: "United States",
    rating: 5,
    text: "Amazing service! Crystal clear 4K quality and never had any buffering issues. The channel selection is incredible with everything I need.",
    plan: "12 Months"
  },
  {
    name: "Sarah Williams",
    location: "United Kingdom",
    rating: 5,
    text: "Best IPTV service I've ever used. Setup was super easy and customer support responded within minutes when I had questions.",
    plan: "24 Months"
  },
  {
    name: "Ahmed Hassan",
    location: "Canada",
    rating: 5,
    text: "Excellent value for money. Works perfectly on all my devices - Smart TV, phone, and Firestick. Highly recommended!",
    plan: "6 Months"
  },
  {
    name: "Emma Thompson",
    location: "Australia",
    rating: 5,
    text: "The VOD library is massive! Over 120k movies and shows. My family loves it and we're definitely renewing our subscription.",
    plan: "12 Months"
  },
  {
    name: "Carlos Rodriguez",
    location: "Spain",
    rating: 5,
    text: "Perfect for international channels. Great quality streams and the Anti-Buffer technology really works. Zero complaints!",
    plan: "24 Months"
  },
  {
    name: "Lisa Chen",
    location: "Singapore",
    rating: 5,
    text: "Instant activation was a game changer. Started watching within 5 minutes of payment. Professional service all around.",
    plan: "3 Months"
  }
];

export function Testimonials() {
  return (
    <section id="testimonials" className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
            What Our <span className="bg-gradient-to-r from-yellow-400 to-purple-600 bg-clip-text text-transparent">Customers Say</span>
          </h2>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto">
            Join thousands of satisfied customers who trust RapideIPTVPlus for their streaming needs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-gray-900 border-gray-800 hover:border-yellow-400/50 transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <Quote className="w-8 h-8 text-yellow-400 mr-3" />
                  <div className="flex space-x-1">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                </div>
                
                <p className="text-gray-300 mb-6 leading-relaxed">"{testimonial.text}"</p>
                
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-white font-semibold">{testimonial.name}</h4>
                    <p className="text-gray-400 text-sm">{testimonial.location}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-yellow-400 text-sm font-medium">{testimonial.plan}</div>
                    <div className="text-gray-500 text-xs">Subscriber</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Trust Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 text-center">
          <div>
            <div className="text-3xl font-bold text-yellow-400 mb-2">10K+</div>
            <div className="text-gray-400">Happy Customers</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-yellow-400 mb-2">99.9%</div>
            <div className="text-gray-400">Uptime</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-yellow-400 mb-2">24/7</div>
            <div className="text-gray-400">Support</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-yellow-400 mb-2">4.9★</div>
            <div className="text-gray-400">Rating</div>
          </div>
        </div>
      </div>
    </section>
  );
}