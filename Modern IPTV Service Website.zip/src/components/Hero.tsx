import { Button } from "./ui/button";
import { Play, Star, Shield, Zap } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Hero() {
  return (
    <section id="home" className="pt-20 min-h-screen bg-gradient-to-br from-black via-gray-900 to-black relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-r from-purple-900/20 to-yellow-400/20 opacity-50"></div>
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-yellow-400/10 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 py-20 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-yellow-400/20 to-purple-600/20 rounded-full border border-yellow-400/30 mb-6">
              <Zap className="w-4 h-4 text-yellow-400 mr-2" />
              <span className="text-yellow-400 text-sm">Premium IPTV Service</span>
            </div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">
              Stream
              <span className="bg-gradient-to-r from-yellow-400 to-purple-600 bg-clip-text text-transparent"> Premium </span>
              TV Content
            </h1>

            <p className="text-gray-300 text-lg md:text-xl mb-8 max-w-2xl">
              Access over 22,000 live TV channels and 120,000+ movies & series with our premium IPTV service. 
              Ultra-HD quality, instant activation, and works on any device.
            </p>

            {/* Features Preview */}
            <div className="flex flex-wrap gap-6 mb-8 justify-center lg:justify-start">
              <div className="flex items-center text-gray-300">
                <Play className="w-5 h-5 text-yellow-400 mr-2" />
                <span>22K+ Channels</span>
              </div>
              <div className="flex items-center text-gray-300">
                <Star className="w-5 h-5 text-yellow-400 mr-2" />
                <span>4K/UHD Quality</span>
              </div>
              <div className="flex items-center text-gray-300">
                <Shield className="w-5 h-5 text-yellow-400 mr-2" />
                <span>24/7 Support</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                size="lg"
                className="bg-gradient-to-r from-yellow-400 to-purple-600 text-black hover:from-yellow-500 hover:to-purple-700 px-8 py-4 text-lg"
              >
                Get Started Now
              </Button>
              <Button 
                size="lg"
                variant="outline"
                className="border-gray-600 text-white hover:bg-gray-800 px-8 py-4 text-lg"
              >
                View Pricing
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="flex items-center justify-center lg:justify-start gap-4 mt-8 text-sm text-gray-400">
              <span>✓ Instant Activation</span>
              <span>✓ No Contract</span>
              <span>✓ 24/7 Support</span>
            </div>
          </div>

          {/* Hero Image */}
          <div className="relative">
            <div className="relative z-10 rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1758577515339-93872db0d37e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFydCUyMHR2JTIwc3RyZWFtaW5nJTIwZW50ZXJ0YWlubWVudHxlbnwxfHx8fDE3NTk0NTI4ODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Smart TV Streaming"
                className="w-full h-auto rounded-2xl"
              />
            </div>
            <div className="absolute -inset-4 bg-gradient-to-r from-yellow-400/20 to-purple-600/20 rounded-2xl blur-lg"></div>
          </div>
        </div>
      </div>
    </section>
  );
}