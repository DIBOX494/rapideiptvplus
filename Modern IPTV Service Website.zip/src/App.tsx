import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { PromoBanner } from "./components/PromoBanner";
import { PricingPlans } from "./components/PricingPlans";
import { Features } from "./components/Features";
import { HowToWatch } from "./components/HowToWatch";
import { Testimonials } from "./components/Testimonials";
import { FAQ } from "./components/FAQ";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-black">
      <Header />
      <PromoBanner />
      <Hero />
      <PricingPlans />
      <Features />
      <HowToWatch />
      <Testimonials />
      <FAQ />
      <Contact />
      <Footer />
    </div>
  );
}